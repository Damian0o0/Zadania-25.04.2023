public class Main {
    public static void main(String[] args) throws Exception{
        RownanieKwadratowe rownanie = new RownanieKwadratowe(1, 2, 1);

        try {
            double[] rozwiazania1 = rownanie.ObliczRozwiazanie();
            WyswietlRozwiazanie(rozwiazania1);
        } catch (DeltaujemnaException jd) {
            System.out.println("Błąd przy rozwiązywaniu równania: " + jd.getMessage());
        }
    }

    private static void WyswietlRozwiazanie(double[] rozwiazania) {
        if (rozwiazania.length == 0) {
            System.out.println("Brak rozwiązań");
        } else if (rozwiazania.length == 1) {
            System.out.println("Jedno rozwiązanie: " + rozwiazania[0]);
        } else {
            System.out.println("Rozwiązania: X1 = " + rozwiazania[0] + ", X2 = " + rozwiazania[1]);
        }
    }
}