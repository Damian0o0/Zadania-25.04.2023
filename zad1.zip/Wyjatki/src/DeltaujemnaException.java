public class DeltaujemnaException extends Exception{
    public DeltaujemnaException(){
        super("Delta ujemna");
    }
}
