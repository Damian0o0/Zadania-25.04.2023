class NiepoprawnaDataException extends Exception {
    public NiepoprawnaDataException(String errorMessage) {
        super(errorMessage);
    }
}
