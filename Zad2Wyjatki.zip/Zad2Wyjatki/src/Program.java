import java.time.LocalDate;

public class Program {
    public static void main(String[] args) {
        try {
            ZwierzakDomowy zwierzak = new ZwierzakDomowy("Kox", "Pies", LocalDate.of(2010, 1, 1));
            System.out.println(zwierzak);
        } catch (NiepoprawnaDataException e) {
            System.out.println("Błąd: " + e.getMessage());
            LocalDate dzisiaj = LocalDate.now();
            try {
                ZwierzakDomowy zwierzak = new ZwierzakDomowy("Kox", "Pies", dzisiaj.minusYears(1));
                System.out.println("Poprawiono datę urodzenia zwierzaka.");
                System.out.println(zwierzak);
            } catch (NiepoprawnaDataException ex) {
                System.out.println("Nie udało się poprawić daty urodzenia zwierzaka: " + ex.getMessage());
            }
        }
    }
}