import java.time.LocalDate;
import java.time.format.DateTimeParseException;

public class Program {
    public static void main(String[] args) {
        try {
            ZwierzakDomowy zwierzak = new ZwierzakDomowy("Burek", "Pies", "2010-05-15");
            System.out.println(zwierzak.toString());
        } catch (NiepoprawnaDataException e) {
            System.out.println("Nie udało się stworzyć zwierzaka: " + e.getMessage());
        } catch (DateTimeParseException e) {
            System.out.println("Nie udało się stworzyć zwierzaka: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Nieznany błąd: " + e.getMessage());
        }
    }
}