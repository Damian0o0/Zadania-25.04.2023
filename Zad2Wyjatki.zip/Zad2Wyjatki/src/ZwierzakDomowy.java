import java.time.LocalDate;
import java.time.Period;
class ZwierzakDomowy {
    private String nazwa;
    private String gatunek;
    private LocalDate data_urodzenia;

    public ZwierzakDomowy(String nazwa, String gatunek, LocalDate data_urodzenia) throws NiepoprawnaDataException {
        if (data_urodzenia.isAfter(LocalDate.now())) {
            throw new NiepoprawnaDataException("Data urodzenia zwierzaka nie może być z przyszłości.");
        }

        int wiek = Period.between(data_urodzenia, LocalDate.now()).getYears();
        if (wiek > 25) {
            throw new NiepoprawnaDataException("Zwierzak nie może mieć więcej niż 25 lat.");
        }

        this.nazwa = nazwa;
        this.gatunek = gatunek;
        this.data_urodzenia = data_urodzenia;
    }

    public int ObliczWiek() {
        return Period.between(data_urodzenia, LocalDate.now()).getYears();
    }

    @Override
    public String toString() {
        return "ZwierzakDomowy{" +
                "nazwa='" + nazwa + '\'' +
                ", gatunek='" + gatunek + '\'' +
                ", data_urodzenia=" + data_urodzenia +
                ", wiek=" + ObliczWiek() +
                '}';
    }
}

